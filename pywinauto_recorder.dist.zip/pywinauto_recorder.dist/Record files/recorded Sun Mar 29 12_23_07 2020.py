# coding: utf-8

#from pywinauto_recorder import *

send_keys("{LWIN}")
time.sleep(0.1)
send_keys("notepad""{ENTER}")

with Region("""Untitled - Notepad||Window""") as r:
	pywinauto_wrapper = r.left_click("""Text Editor||Edit%(-157,-143)""")
	send_keys("This is a test.""{ENTER}")
	pywinauto_wrapper.draw_outline()

with Region("""*Untitled - Notepad||Window""") as r:
	r.left_click("""||TitleBar->Close||Button%(2,-1)""")
	r.left_click("""Notepad||Window->Don't Save||Button%(-24,7)""")
	
